import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-old-journal-entry',
  templateUrl: './old-journal-entry.page.html',
  styleUrls: ['./old-journal-entry.page.scss'],
})
export class OldJournalEntryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
