import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deep-breathing',
  templateUrl: './deep-breathing.page.html',
  styleUrls: ['./deep-breathing.page.scss'],
})
export class DeepBreathingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
