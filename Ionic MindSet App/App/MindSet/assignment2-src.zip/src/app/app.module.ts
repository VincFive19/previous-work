import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ModalNamePageModule } from './modal-name/modal-name.module';
import { ModalEmailPageModule } from './modal-email/modal-email.module';
import { ModalPsychologistEmailPageModule } from './modal-psychologist-email/modal-psychologist-email.module';

import { NewJournalEntryPageModule } from './new-journal-entry/new-journal-entry.module';
import { OldJournalEntryPageModule } from './old-journal-entry/old-journal-entry.module';
import { EditjournalentryPageModule } from './editjournalentry/editjournalentry.module';

import { IonicStorageModule } from '@ionic/storage';
import { EmailComposer } from '@ionic-native/email-composer/ngx';

import { File } from '@ionic-native/file/ngx'



@NgModule({
  
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule, ModalNamePageModule, ModalEmailPageModule, ModalPsychologistEmailPageModule, NewJournalEntryPageModule, OldJournalEntryPageModule, EditjournalentryPageModule, IonicStorageModule.forRoot()], 
  providers: [
    StatusBar,
    SplashScreen,
    EmailComposer,
    File,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  
}
