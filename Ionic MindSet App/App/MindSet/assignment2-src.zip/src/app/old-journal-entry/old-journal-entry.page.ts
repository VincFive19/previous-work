import { Component, OnInit } from '@angular/core';
import { NavParams, ModalController } from '@ionic/angular';


@Component({
  selector: 'app-old-journal-entry',
  templateUrl: './old-journal-entry.page.html',
  styleUrls: ['./old-journal-entry.page.scss'],
})
export class OldJournalEntryPage implements OnInit {

  journals;

  constructor(private navParams: NavParams, private modalController: ModalController) { }

  //on init gets journals from storage
  ngOnInit() {
    this.journals = this.navParams.get("journals");
  }

  //closes modal
  closeModal() {
    this.modalController.dismiss();
  }

}
