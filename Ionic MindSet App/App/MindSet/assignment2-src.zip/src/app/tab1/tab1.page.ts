import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router'
import { NavParams, NavController } from '@ionic/angular';

import { Storage } from '@ionic/storage';
import { Chart } from 'chart.js'

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  name: string;
  routeParamsSubscription;
  quote: string;
  quoteAuthor: string;
  journals
  chart: any
  journalChart

  @ViewChild('journalChart') canvas;

  constructor(private route: ActivatedRoute, private storage: Storage, public navCtrl: NavController) {
    this.storage.get("journals").then(val => {
      this.journals = val;
    });
  }

  labels = []
  data = []

  //on view enter run quotes, get storage value name
  async ionViewWillEnter() {
    this.storage.get("name").then(val => {
      this.name = val;
    });

    this.storage.get("journals").then(val => {
      this.journals = val;
    });

    this.labels = []
    this.data = []

    for (let i = 0; this.journals.length > i; i++) {
      this.labels.unshift(this.journals[i].time)
      this.data.unshift(this.journals[i].intensity)
    }
    console.log(this.data)



    //console.log(this.journals.intensity)
    this.journalChart = {
      type: 'line',
      data: {
        datasets: [{
          label: "Intensity",
          data: this.data,
        }],
        "labels":
          this.labels

      },

    }


    let quotes = [
      { quote: "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.", author: "Buddha" },
      { quote: "The real meditation is how you live your life. ", author: "Jon Kabat-Zinn" },
      { quote: "Surrender to what is. Let go of what was. Have faith in what will be.", author: "Sonia Ricotti" },
      { quote: "The present moment is filled with joy and happiness. If you are attentive, you will see it.", author: "Thich Nhat Hanh" },
      { quote: "Mindfulness isn’t difficult. We just need to remember to do it.", author: "Sharon Salzberg" },
      { quote: "Be happy in the moment, that’s enough. Each moment is all we need, not more.", author: "Mother Teresa" },
      { quote: "“What day is it?” asked Pooh. “It’s today,” squeaked Piglet. “My favourite day,” said Pooh.", author: "A A Milne" },
      { quote: "The little things? The little moments? They aren’t little.", author: "Jon Kabat-Zinn" },
      { quote: "When we get too caught up in the busyness of the world, we lose connection with one another – and ourselves.", author: "Jack Kornfield" },
      { quote: "You are the sky. Everything else is just the weather.", author: "Pema Chödrön" },
      { quote: "Fear is a natural reaction to moving closer to the truth.", author: "Pema Chödrön" }

    ];

    let i = Math.floor(Math.random() * quotes.length);

    this.quote = quotes[i].quote;
    this.quoteAuthor = quotes[i].author;
    console.log(quotes[i].author);

    this.chart = new Chart(this.canvas.nativeElement, this.journalChart);
    this.journalChart.update;
  }



  //Open Settings
  openSettings() {
    this.navCtrl.navigateForward('/settings');
  }
  //On init
  ngOnInit() {




    //let name = this.storage.get("name")
    //this.name = this.route.snapshot.paramMap.get('name')
    // this.routeParamsSubscription = this.routeParamsSubscription.params.subscribe(params => {
    //   this.name = params['name'];
    // })
  }
  //Unused on destroy
  ngOnDestroy() {
    // this.routeParamsSubscription.unsubscribe();
  }




}
