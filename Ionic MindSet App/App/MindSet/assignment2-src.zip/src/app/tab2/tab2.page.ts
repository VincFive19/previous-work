import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Storage } from '@ionic/storage';

import { NewJournalEntryPage } from '../new-journal-entry/new-journal-entry.page';
import { OldJournalEntryPage } from '../old-journal-entry/old-journal-entry.page';
import { EditjournalentryPage } from '../editjournalentry/editjournalentry.page';

import { StorageService } from '../storage.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  journals = new Array()

  constructor(private storage: Storage, private modalController: ModalController, private storageService: StorageService) {


    storage.get("journals").then(val => {
      this.journals = val;
    });
  }

  async ngOnInit() {

  }


  //test to see if data is being transferred
  ionViewWillEnter() {
    console.log(this.journals)
  }

  ionViewWillLeave() {
    this.storage.set("journals", this.journals);
  }

  //Add Journal Entry, open modal
  async addEntry() {
    console.log("this")
    const modal = await this.modalController.create({
      component: NewJournalEntryPage,
      componentProps: { journals: this.journals }
    });

    modal.onDidDismiss()
      .then((retval) => {
        this.journals = retval.data;
        //this.storage.set("journals", this.journals);
        this.storageService.storageJournals(this.journals);
      });
    return modal.present();
  }

  //edit journal entry opens edit modal
  async editEntry(index) {
    console.log("this")
    const modal = await this.modalController.create({
      component: EditjournalentryPage,
      componentProps: { journals: this.journals[index] }
    });

    modal.onDidDismiss()
      .then((retval) => {
        this.journals[index] = retval.data;
        //this.storage.set("journals", this.journals);
        this.storageService.storageJournals(this.journals);
      });
    return modal.present();
  }

  //view journal entry, opens view modal
  async viewEntry(index) {
    console.log("this")
    const modal = await this.modalController.create({
      component: OldJournalEntryPage,
      componentProps: { journals: this.journals[index] }
    });

    // modal.onDidDismiss()
    //   .then((retval) => {
    //     this.name = retval.data;
    //     this.storage.set("name", this.name);
    //   });
    return modal.present();

  }

  //deletes a journal entry
  deleteEntry(index) {
    if (confirm("Delete " + this.journals[index] + "?")) {
      this.journals.splice(index, 1)
    }

  }

}
