import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guided-meditation',
  templateUrl: './guided-meditation.page.html',
  styleUrls: ['./guided-meditation.page.scss'],
})
export class GuidedMeditationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
